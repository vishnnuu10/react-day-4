// 1.importing the express
const express =require("express")
const employeeModel = require("./model")

// 2.initialize express
const app = new express("")

//3.middleware
app.use(express.urlencoded({extended:true}))
app.use(express.json())

// 4.API creation
app.get("/",(req,res)=>{
    res.send("message from server")
})

app.get("/trial",(req,res)=>{
    res.send("message from  trail API ")
})

//api to add data to db
app.post("/add",async(req,res)=>{
    const react =await new employeeModel(req.body);
    res.send("data added")
})
//api to view data to db
app.get("/view",async(req,res)=>{
    let result = await employeeModel.find();
    res.json(result);
})


// 5.port
app.listen(4000,()=>{
    console.log("port 8080 is up and running")
})

app.get("/data",(req,res)=>{
    res.json({"name":"vishnu","age":19})
})
app.post("")